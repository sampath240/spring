package com.example.sampath;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SampathApplication {

	public static void main(String[] args) {
		SpringApplication.run(SampathApplication.class, args);
	}
}
